const routes = {
  "/": renderOverview,
  "/add-recipe": renderAddRecipe,
  "/recipes": renderRecipes,
  "/ratings": renderRatings,
  "/health": renderHealth,
};

const apiBaseUrl = (window.MEALMINT_CONFIG && window.MEALMINT_CONFIG.apiBaseUrl) || "https://<api-id>.cloudfront.net";
const app = document.querySelector("#app");

function setActive(path) {
  document.querySelectorAll("nav a").forEach((link) => {
    link.classList.toggle("active", link.dataset.route === path);
  });
}

function navigate(path) {
  history.pushState({}, "", path);
  render();
}

function render() {
  const path = routes[location.pathname] ? location.pathname : "/";
  setActive(path);
  routes[path]();
}

function renderOverview() {
  app.innerHTML = `
    <div class="grid">
      <div class="card"><span>API distribution</span><strong>${escapeHtml(apiBaseUrl)}</strong></div>
      <div class="card"><span>Static origin</span><strong>S3 + OAC</strong></div>
      <div class="card"><span>Routing mode</span><strong>SPA rewrite</strong></div>
    </div>
    <p class="status">Ready for deployment</p>
    <p>This dashboard is intentionally pre-built. Use the left menu to search recipes, add recipes, check ratings, and verify deployment health.</p>
  `;
}

function renderAddRecipe() {
  app.innerHTML = `
    <section class="form-section" aria-labelledby="add-recipe-title">
      <h2 id="add-recipe-title">Add Recipe</h2>
      <p class="muted">Create a recipe by calling <code>POST /recipes</code>.</p>
      <form id="addRecipeForm" class="recipe-form">
        <label>
          <span>Recipe ID</span>
          <input id="newRecipeId" name="recipeId" value="z-501" required autocomplete="off" />
        </label>
        <label>
          <span>Name</span>
          <input id="newRecipeName" name="name" value="Coconut Lentil Soup" required autocomplete="off" />
        </label>
        <label>
          <span>Author</span>
          <input id="newRecipeAuthor" name="author" value="maya" required autocomplete="off" />
        </label>
        <button type="submit">Add Recipe</button>
      </form>
      <pre id="result">Fill in recipeId, name, and author, then click Add Recipe.</pre>
    </section>
  `;
  document.querySelector("#addRecipeForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const payload = {
      recipeId: document.querySelector("#newRecipeId").value.trim(),
      name: document.querySelector("#newRecipeName").value.trim(),
      author: document.querySelector("#newRecipeAuthor").value.trim(),
    };
    if (!payload.recipeId || !payload.name || !payload.author) {
      document.querySelector("#result").textContent = "recipeId, name, and author are required.";
      return;
    }
    await callApi("/recipes", {
      method: "POST",
      headers: {
        accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });
  });
}

function renderRecipes() {
  app.innerHTML = `
    <h2>Recipe Search</h2>
    <div class="toolbar">
      <input id="q" value="thai" aria-label="Search keyword" />
      <button id="search">Search API</button>
    </div>
    <pre id="result" class="json-output">Click Search API to call GET /recipes/search?q=thai</pre>
  `;
  document.querySelector("#search").addEventListener("click", async () => {
    const q = encodeURIComponent(document.querySelector("#q").value || "");
    await callApi(`/recipes/search?q=${q}`);
  });
}

function renderRatings() {
  app.innerHTML = `
    <h2>Recipe Rating</h2>
    <div class="toolbar">
      <input id="recipeId" value="r-001" aria-label="Recipe ID" />
      <button id="rating">Get Rating</button>
    </div>
    <pre id="result">Click Get Rating to call GET /recipes/{id}/rating</pre>
  `;
  document.querySelector("#rating").addEventListener("click", async () => {
    const id = encodeURIComponent(document.querySelector("#recipeId").value || "");
    await callApi(`/recipes/${id}/rating`);
  });
}

function renderHealth() {
  app.innerHTML = `
    <h2>Deployment Health</h2>
    <p><span class="status warn">Manual check</span></p>
    <ul>
      <li>Open <code>/recipes</code> directly to verify Lambda@Edge SPA rewrite.</li>
      <li>Confirm this static site is served only through CloudFront OAC.</li>
      <li>Confirm API calls use the default API CloudFront domain.</li>
    </ul>
    <button class="secondary" id="home">Back to Overview</button>
  `;
  document.querySelector("#home").addEventListener("click", () => navigate("/"));
}

async function callApi(path, options = {}) {
  const result = document.querySelector("#result");
  const method = options.method || "GET";
  result.textContent = `Calling ${method} ${apiBaseUrl}${path} ...`;
  try {
    const response = await fetch(`${apiBaseUrl}${path}`, {
      headers: { accept: "application/json" },
      ...options,
    });
    const body = await response.text();
    renderResult(result, response.status, body);
  } catch (err) {
    result.textContent = `Request failed. Check assets/config.js apiBaseUrl and CORS.\n\n${err}`;
  }
}

function renderResult(target, status, body) {
  const parsed = parseJSON(body);
  if (parsed.ok) {
    target.classList.add("json-output");
    target.innerHTML = `<span class="http-status">HTTP ${status}</span>\n\n${syntaxHighlightJSON(parsed.value)}`;
    return;
  }
  target.classList.remove("json-output");
  target.textContent = `HTTP ${status}\n\n${body}`;
}

function parseJSON(value) {
  try {
    return { ok: true, value: JSON.parse(value) };
  } catch {
    return { ok: false };
  }
}

function syntaxHighlightJSON(value) {
  return escapeHtml(JSON.stringify(value, null, 2)).replace(
    /("(?:\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*"(?:\s*:)?|\btrue\b|\bfalse\b|\bnull\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    (match) => {
      let cls = "json-number";
      if (match.startsWith('"')) {
        cls = match.endsWith(":") ? "json-key" : "json-string";
      } else if (match === "true" || match === "false") {
        cls = "json-boolean";
      } else if (match === "null") {
        cls = "json-null";
      }
      return `<span class="${cls}">${match}</span>`;
    },
  );
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

document.querySelectorAll("nav a").forEach((link) => {
  link.addEventListener("click", (event) => {
    event.preventDefault();
    navigate(link.dataset.route);
  });
});
window.addEventListener("popstate", render);
render();
