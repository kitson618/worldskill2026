// MealMint static dashboard runtime configuration.
// Competitors may update only this value after creating the API CloudFront distribution.
window.MEALMINT_CONFIG = {
  apiBaseUrl: "https://<api-id>.cloudfront.net"
};
